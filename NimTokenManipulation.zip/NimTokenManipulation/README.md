# TokenManipulation
Nim TokenManipulation with Syscalls

This repository takes much code from a private project of [whydee86](https://github.com/whydee86). I used his Token Manipulation code as base to improve it via Syscalls + WINSTA permission change.

## Instalation / Setup

`nimble install cligen,winim`

Tested with Nim version 1.6.2.

Compile via `nim c -d:release TokenManipulation.nim`


```
Example Usage:
    echo "Usage:"
    echo "TokenManipulation.exe --list -> Lists available Tokens"
    echo "TokenManipulation.exe --listAll -> Lists all Tokens by impersonating SYSTEM before"
    echo "TokenManipulation.exe --username -> Impersonates the specified user"
    echo "TokenManipulation.exe --getSystem -> GetSystem"
    echo "TokenManipulation.exe --createProcessWithTokenW  --username <username> --binary C:\\windows\\system32\\mspaint.exe -> Spawns mspaint.exe as username"
    echo "Tokenmanipulation.exe --createProcessWithTokenW --pid 3448 --binary C:\\windows\\system32\\notepad.exe -> Impersonate the user of PID 3448 to spawn notepad.exe"
	echo "Tokenmanipulation.exe --createProcessWithTokenW --pid 3448 --display --binary C:\\windows\\system32\\notepad.exe -> Impersonate the user of PID 3448 to spawn notepad.exe (visible window)"
    echo "TokenManipulation.exe --createProcessWithTokenW --pid 19260 -> Impersonate the process with the ID 19260 to spawn cmd.exe (default)"

Usage:
Options:
  -h, --help                                    Displays this help menu
  --help-syntax                                 advanced: prepend,plurals,..
  -g, --getSystem                bool    false  Impersonate the SYSTEM account
  -c, --createProcessWithTokenW  bool    false  Spawn a new process with a duplicated token
  -d, --display                  bool    false  Use CREATE_NEW_CONSOLE instead of CREATE_NO_WINDOW to spawn a new process (visible process)
  -l, --list                     bool    false  List available user tokens
  --listAll                      bool    false  List all user tokens by impersonating SYSTEM before
  -e, --elevated                 bool    false  GetSystem before doing anything else
  -i, --impersonate              bool    false  Impersonate the target user for the current process
  --impersonateparent            bool    false  Impersonate the target user for the parent process
  -p=, --pid=                    DWORD   0      Target process ID to impersonate
  -u=, --username=               string  ""     Target username to impersonate
  -b=, --binary=                 string  ""     Binary to spawn via createProcessWithTokenW
  --examples                     bool    false  Displays usage examples
	
```

Consider this as Pre-ALPHA. I'm actively working on it.

You can also do some funny stuff such as executing it from a command line to set the new users Token for all Console Threads (Parent Process):

![alt text](https://github.com/S3cur3Th1sSh1t-Sponsors/NimTokenManipulation/raw/main/Images/FunwithSystem.PNG)