# BlockDLLs
 
This Code can be used to block a DLL from being loaded in the current or a remote process by hooking `NtCreateSection` like described in this blog post:

[https://waawaa.github.io/es/amsi_bypass-hooking-NtCreateSection/](https://waawaa.github.io/es/amsi_bypass-hooking-NtCreateSection/)

The difference to the POC is, that it:

1. Is Written PIC-Style and can therefore be used or injected as Shellcode
2. Easy to modify in terms of blocking other DLLs instead of `amsi.dll`

So, what is a use case? Imagine you have any process, which did not yet load `amsi.dll`. That's almost everywhere the case, except for Scripting-Language host processes such as `powershell.exe`, `mshta.exe` or such. Before executing any .NET executable in this remote process you could inject this shellcode, so that `amsi.dll` will never be loaded at all. Procedure would be:

1. Inject the shellcode into the current or remote process
2. Inject the Powershell/.NET/.JS Payload afterwards, which cannot be detected by AMSI anymore, as that won't load at all.

Of course this PoC can be modified to block custom EDR-Speific AMSI Provider DLLs or other DLLs. But for it to work the target DLL MUST not have loaded already in the target process, otherwise it will not work.

# How to build?

Type `make`

# How to get Shellcode?

Use `extract.sh`
