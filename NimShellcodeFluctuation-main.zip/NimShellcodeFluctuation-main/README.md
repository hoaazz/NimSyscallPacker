# NimShellcodeFluctuation
Nim Port of the original repo:  https://github.com/mgeeky/ShellcodeFluctuation

This is the initial working PoC. I'm planning to switch to Syscalls instead of using Win32, use custom API's for hooks and integrate this into the Packer.

Maybe I'll also switch from XOR to AES encryption or similar.

At the moment the Encryption/Decryption Key plus the Shellcode address and more values like the protection have to be set manually to use this. 

The `Example.nim` file contains everything you need to get started. Of course when using C2-Shellcode you don't need to call `Sleep` by yourself (this is just to trigger everything for the PoC), that should be done by your C2 itself. For the moment this is only compatible with C2-Frameworks that use the Win32 Sleep function.

```nim

import winim
import Fluctuation

echo "Trying to hook Sleep"

if (hookSleep()):
    echo "Hooked Sleep successfully!"
    
    type
      ThreeStringAddress = array[12, byte]
    let names: ThreeStringAddress = [byte 0xAA,0xAA,0xAA,0xAA,0xAA,0xAA,0xAA,0xAA,0xAA,0xAA,0xAA,0xAA]
    g_fluctuationData.shellcodeAddr = unsafeAddr names[0]
    echo "Shellcode address:"
    echo repr(g_fluctuationData.shellcodeAddr)
    g_fluctuationData.shellcodeSize = size_t(len(names))
    echo "Shellcode Size:"
    echo repr(g_fluctuationData.shellcodeSize)
    when defined(amd64):
        g_fluctuationData.encodeKey = 0xDEADB33f
    when defined(i386):
        g_fluctuationData.encodeKey = 0xDEAD
    #g_fluctuationData.encodeKey = 0xDEAD
    g_fluctuationData.currentlyEncrypted = false
    g_fluctuationData.protect = PAGE_READWRITE
    g_fluctuate = FluctuateToRW
    #[Not finished yet, some troubleshooting left
    g_fluctuate = FluctuateToNA
    g_fluctuationData.protect = PAGE_NOACCESS
    AddVectoredExceptionHandler(1, cast[PVECTORED_EXCEPTION_HANDLER](VEHHandler))
    ]#
    echo "Calling Sleep"
    Sleep(2500)
    echo "No Crash, everything went fine and as expected"
else:
    echo "Failed to hook Sleep"
    quit(1)

```
