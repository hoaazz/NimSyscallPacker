# NimEkko
 
This is a Nim-Port of the Ekko Sleep obfuscation by @C5pider, original work: https://github.com/Cracked5pider/Ekko

It uses random Keys per round and encrypts the whole PE-Image + sets the permissions to RW.

This code can be used in a Nim-C2 as alternative to Win32 Sleep. Maybe I'll also add it as alternative to ShellcodeFluctuation in the Packer.

Tested with Nim version 1.6.6 and winim Version 3.9.0.