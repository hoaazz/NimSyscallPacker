# SharpHellsGate_NetFramework

This is @am0nsec's [SharpHellsGate](https://github.com/am0nsec/SharpHellsGate) ported to .NET Framework.

By not using .NET Core it's much easier to load this binary reflectively to execute shellcode via HellsGate technique.

Without the help of @am0nsec's this would never exist from my side, had a lot of questions by porting this.