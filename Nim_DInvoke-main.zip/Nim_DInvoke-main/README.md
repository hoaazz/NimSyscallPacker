# Nim_DInvoke
D/Invoke via Nim

This was heavily inspired by the [NanoDump](https://github.com/helpsystems/nanodump/blob/main/source/dinvoke.c) D/Invoke code.

To use other functions as the ones in the example code you need to generate a hash via the following:

```batch
gethash <functionname>
```


```batch
c:\temp>GetHash.exe OpenProcess
3768626
```

The function can than be used like this:

```cpp
const
  KERNEL32_DLL* = "kernel32.dll"
const
  OpenProcess_HASH * = 3768626
type
  OpenProcess_t* = proc (dwDesiredAccess: DWORD, bInheritHandle: WINBOOL, dwProcessId: DWORD): HANDLE {.stdcall.}

MyOpenProcess = cast[OpenProcess_t](cast[LPVOID](get_function_address(cast[HMODULE](get_library_address(KERNEL32_DLL, FALSE)), OpenProcess_HASH, 0)))

echo "[*] Calling OpenProcess via D/Invoke"
let pHandle = MyOpenProcess(
    PROCESS_ALL_ACCESS, 
    false, 
    cast[DWORD](processID)
)
```

What is the advantage? The function is not exposed in the executable anymore as it's loaded on runtime. Consider this still as beta, as I just finished it and some functions need to be improved/fixed yet. But this example is already working.

This will get integrated into the packer in the future, so that it's not exposing any Win32 functions anymore.
